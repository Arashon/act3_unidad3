function calcular() {
    let valor1 = document.getElementById("valor1").value;
    let valor2 = document.getElementById("valor2").value;
    let operacion = document.getElementById("operacion").value;
  
    switch (operacion) {
      case "sumar":
        document.getElementById("resultado").textContent = Number(valor1) + Number(valor2);
        break;
      case "restar":
        document.getElementById("resultado").textContent = valor1 - valor2;
        break;
      case "multiplicar":
        document.getElementById("resultado").textContent = valor1 * valor2;
        break;
      case "dividir":
        if (valor2 == 0) {
          document.getElementById("resultado").textContent = "Error: división por 0";
        } else {
          document.getElementById("resultado").textContent = valor1 / valor2;
        }
        break;
      case "potencia":
        document.getElementById("resultado").textContent = Math.pow(valor1, valor2);
        break;
      case "mayor":
        if (valor1 > valor2) {
          document.getElementById("resultado").textContent = "Valor 1 es mayor";
        } else if (valor1 < valor2) {
          document.getElementById("resultado").textContent = "Valor 2 es mayor";
        } else {
          document.getElementById("resultado").textContent = "Valores iguales";
        }
        break;
      case "igual":
        if (valor1 == valor2) {
          document.getElementById("resultado").textContent = "Valores iguales";
        } else {
          document.getElementById("resultado").textContent = "Valores diferentes";
        }
        break;
    }
  }