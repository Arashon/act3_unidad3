let animales = [
    { nombre: "León", especie: "Felino", alimentacion: "Carnívoro" },
    { nombre: "Cebra", especie: "Équido", alimentacion: "Herbívoro" },
    { nombre: "Cocodrilo", especie: "Crocodylia", alimentacion: "Carnívoro" }
  ];
  
  function mostrarAnimales() {
    let tbody = document.getElementById("animales");
  
    tbody.innerHTML = "";
  
    for (let animal of animales) {
      let tr = document.createElement("tr");
  
      let tdNombre = document.createElement("td");
      tdNombre.textContent = animal.nombre;
      tr.appendChild(tdNombre);
  
      let tdEspecie = document.createElement("td");
      tdEspecie.textContent = animal.especie;
      tr.appendChild(tdEspecie);
  
      let tdAlimentacion = document.createElement("td");
      tdAlimentacion.textContent = animal.alimentacion;
      tr.appendChild(tdAlimentacion);
  
      tbody.appendChild(tr);
    }
  }
  
  function ordenar() {
    animales.sort(function(a, b) {
      let nombreA = a.nombre.toUpperCase();
      let nombreB = b.nombre.toUpperCase();
  
      if (nombreA < nombreB) {
        return -1;
      }
  
      if (nombreA > nombreB) {
        return 1;
      }
  
      return 0;
    });
  
    mostrarAnimales();
  }
  
  function filtrar() {
    let filtro = document.getElementById("filtro").value.toUpperCase();
  
    let animalesFiltrados = animales.filter(function(animal) {
      return animal.especie.toUpperCase().indexOf(filtro) > -1;
    });
  
    let tbody = document.getElementById("animales");
  
    tbody.innerHTML = "";
  
    for (let animal of animalesFiltrados) {
      let tr = document.createElement("tr");
  
      let tdNombre = document.createElement("td");
      tdNombre.textContent = animal.nombre;
      tr.appendChild(tdNombre);
  
      let tdEspecie = document.createElement("td");
      tdEspecie.textContent = animal.especie;
      tr.appendChild(tdEspecie);
  
      let tdAlimentacion = document.createElement("td");
      tdAlimentacion.textContent = animal.alimentacion;
      tr.appendChild(tdAlimentacion);
  
      tbody.appendChild(tr);
    }
  }
  
  mostrarAnimales();




