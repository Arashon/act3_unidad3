function calcular() {
    let palabra1 = document.getElementById("palabra1").value;
    let palabra2 = document.getElementById("palabra2").value;
    let palabra3 = document.getElementById("palabra3").value;
    let palabra4 = document.getElementById("palabra4").value;
    let palabra5 = document.getElementById("palabra5").value;
  
    let palabras = [palabra1, palabra2, palabra3, palabra4, palabra5];
  
    let palabraPrimera = "";
    let palabraUltima = "";
  
    for (let i = 0; i < palabras.length; i++) {
      palabraPrimera += palabras[i][0];
      palabraUltima += palabras[i][palabras[i].length - 1];
    }
  
    let palabraCorta = palabras.reduce(function(a, b){return a.length < b.length ? a : b});
  
    let palabrasA = 0;
  
    for (let i = 0; i < palabras.length; i++) {
      if (palabras[i].startsWith("A") || palabras[i].startsWith("a")) {
        palabrasA++;
      }
    }
  
    document.getElementById("palabraPrimera").textContent = palabraPrimera;
    document.getElementById("palabraUltima").textContent = palabraUltima;
    document.getElementById("palabraCorta").textContent = palabraCorta;
    document.getElementById("palabrasA").textContent = palabrasA;
  }