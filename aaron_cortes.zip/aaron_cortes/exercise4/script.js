function calcular() {
    let valor1 = parseInt(document.getElementById("valor1").value);
    let valor2 = parseInt(document.getElementById("valor2").value);
    let valor3 = parseInt(document.getElementById("valor3").value);
    let valor4 = parseInt(document.getElementById("valor4").value);
    let valor5 = parseInt(document.getElementById("valor5").value);
  
    let valores = [valor1, valor2, valor3, valor4, valor5];
  
    let valoresOrdenados = valores.sort(function(a, b){return a - b});
    let suma = valores.reduce(function(a, b){return a + b});
    let promedio = suma / valores.length;
    let mayor = Math.max.apply(null, valores);
    let menor = Math.min.apply(null, valores);
  
    let resultados = document.getElementById("resultados");
    resultados.innerHTML = "<p>Los valores ordenados de menor a mayor son: " + valoresOrdenados + "</p>";
    resultados.innerHTML += "<p>La suma de los valores es: " + suma + "</p>";
    resultados.innerHTML += "<p>El promedio de los valores es: " + promedio + "</p>";
    resultados.innerHTML += "<p>El mayor de los valores es: " + mayor + "</p>";
    resultados.innerHTML += "<p>El menor de los valores es: " + menor + "</p>";
  }