function calcular() {
    let valor1 = document.getElementById("valor1").value;
    let valor2 = document.getElementById("valor2").value;
    let valor3 = document.getElementById("valor3").value;
    let valor4 = document.getElementById("valor4").value;
    let valor5 = document.getElementById("valor5").value;
    let valor6 = document.getElementById("valor6").value;
    let valor7 = document.getElementById("valor7").value;
    let valor8 = document.getElementById("valor8").value;
    let valor9 = document.getElementById("valor9").value;
    let valor10 = document.getElementById("valor10").value;
  
    let numeros = [valor1, valor2, valor3, valor4, valor5, valor6, valor7, valor8, valor9, valor10];
  
    let pares = 0;
    let impares = 0;
    let positivos = 0;
    let negativos = 0;
    let entre10y100 = 0;
  
    for (let i = 0; i < numeros.length; i++) {
      if (numeros[i] % 2 == 0) {
        pares++;
      } else {
        impares++;
      }
  
      if (numeros[i] > 0) {
        positivos++;
      } else if (numeros[i] < 0) {
        negativos++;
      }
  
      if (numeros[i] >= 10 && numeros[i] <= 100) {
        entre10y100++;
      }
    }
  
    document.getElementById("pares").textContent = `${pares} (${pares + impares} en total)`;
    document.getElementById("impares").textContent = `${impares} (${pares + impares} en total)`;
    document.getElementById("positivos").textContent = `${positivos} (${positivos + negativos} en total)`;
    document.getElementById("negativos").textContent = `${negativos} (${positivos + negativos} en total)`;
    document.getElementById("entre10y100").textContent = entre10y100;
  }