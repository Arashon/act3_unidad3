function actualizar() {
    let foto = document.getElementById("foto").files[0];
    let nombreCompleto = document.getElementById("nombreCompleto").value;
    let rut = document.getElementById("rut").value;
    let fechaNacimiento = document.getElementById("fechaNacimiento").value;
    let correo = document.getElementById("correo").value;
    let profesion = document.getElementById("profesion").value;
  
    let fotoURL = URL.createObjectURL(foto);
  
    document.getElementById("foto").src = fotoURL;
    document.getElementById("nombreCompleto").textContent = nombreCompleto;
    document.getElementById("rut").textContent = rut;
    document.getElementById("fechaNacimiento").textContent = fechaNacimiento;
    document.getElementById("correo").textContent = correo;
    document.getElementById("profesion").textContent = profesion;
  }
  
  document.getElementById("foto").addEventListener("change", function() {
    let foto = document.getElementById("foto").files[0];
    let fotoURL = URL.createObjectURL(foto);
    document.getElementById("foto").src = fotoURL;
  });